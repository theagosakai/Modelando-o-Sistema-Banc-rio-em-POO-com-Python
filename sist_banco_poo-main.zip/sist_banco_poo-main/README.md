# Sobre o projeto
Projeto de um sistema baseado em CRUD de realização de operações em um banco.
